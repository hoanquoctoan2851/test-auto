import { Selector } from "testcafe";

fixture`E-commerce Playground - Product Comparison`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("T004 - Product Comparison – Add Product", async (t) => {
  const TEST_ID = "T004";
  const FUNCTION_NAME = "Product Comparison – Add Product";
  const TEST_NAME =
    "Hover product and add to comparison list, then verify notification appears.";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const productThumb = Selector(".product-thumb-top").nth(0);
  const compareBtn = productThumb.parent().find(".btn-compare");
  const notification = Selector("#notification-box-top");

  let testStatus = "FAIL";

  console.log("Hovering over the first product...");
  await t.hover(productThumb).wait(1000);

  console.log("Clicking 'Add to Compare' button...");
  await t.click(compareBtn);

  const notificationVisible = await notification.exists;

  if (notificationVisible) {
    console.log(
      "PASS — Notification displayed, product added to comparison successfully.",
    );
    testStatus = "PASS";
  } else {
    console.log(
      "FAIL — Notification not displayed, product may not have been added.",
    );
    await t
      .expect(notification.exists)
      .ok("Expected notification after clicking compare button.");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});

fixture`E-commerce Playground - Product Comparison Max Limit`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("TC005 - Product Comparison – Maximum Product Limit", async (t) => {
  const TEST_ID = "TC005";
  const FUNCTION_NAME = "Product Comparison – Maximum Product Limit";
  const TEST_NAME =
    "Add 5 products to comparison and verify Add to Cart count = 4";
  const notification = Selector("#notification-box-top");
  const compareTab = Selector('[aria-label="Compare"]');
  const addToCartSelector = Selector('[value="Add to Cart"]');

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  let testStatus = "FAIL";
  let notificationsShown = 0;

  for (let i = 0; i < 5; i++) {
    const productThumb = Selector(".product-thumb-top").nth(i);
    const compareBtn = productThumb.parent().find(".btn-compare");

    console.log(`Adding product ${i + 1} to comparison...`);

    await t.hover(productThumb).wait(700).click(compareBtn);

    try {
      await t
        .expect(notification.exists)
        .ok(`Notification not shown after adding product ${i + 1}`);
      notificationsShown++;
      console.log(`Product ${i + 1}: notification shown.`);
    } catch (err) {
      console.log(`Product ${i + 1}: notification NOT shown.`);
      await t
        .expect(notification.exists)
        .ok(`Expected notification after adding product ${i + 1}`);
    }

    await t.wait(1000);
  }

  console.log("Clicking Compare tab...");
  await t.click(compareTab);
  await t.wait(2000);

  const addToCartCount = await addToCartSelector.count;
  console.log("Add to Cart elements found:", addToCartCount);

  if (addToCartCount === 4) {
    testStatus = "PASS";
    console.log("PASS — Add to Cart count is 4.");
  } else {
    console.log(
      `FAIL — Expected 4 Add to Cart elements but found ${addToCartCount}.`,
    );
    await t
      .expect(addToCartCount)
      .eql(4, "Expected 4 'Add to Cart' elements on comparison page");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Notifications shown: ${notificationsShown} / 5`);
  console.log(`Add to Cart elements found: ${addToCartCount}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});

fixture`E-commerce Playground - Product Comparison Remove`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("TC006 - Product Comparison – Remove Product", async (t) => {
  const TEST_ID = "TC006";
  const FUNCTION_NAME = "Product Comparison – Remove Product";
  const TEST_NAME =
    "Add 5 products to comparison, then remove one and verify count decreased by 1";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const notification = Selector("#notification-box-top");
  const compareTab = Selector('[aria-label="Compare"]');
  const addToCartSelector = Selector('[value="Add to Cart"]');
  const removeButton = Selector(".btn-danger");
  const successAlert = Selector(".alert-success");

  let testStatus = "FAIL";
  let notificationsShown = 0;

  for (let i = 0; i < 5; i++) {
    const productThumb = Selector(".product-thumb-top").nth(i);
    const compareBtn = productThumb.parent().find(".btn-compare");

    console.log(`Adding product ${i + 1} to comparison...`);
    await t.hover(productThumb).wait(700).click(compareBtn);

    try {
      await t
        .expect(notification.exists)
        .ok(`Notification not shown for product ${i + 1}`);
      notificationsShown++;
      console.log(`Product ${i + 1}: notification shown.`);
    } catch {
      console.log(`Product ${i + 1}: notification NOT shown.`);
      await t
        .expect(notification.exists)
        .ok(`Expected notification after adding product ${i + 1}`);
    }

    await t.wait(1000);
  }

  console.log("Navigating to comparison page...");
  await t.click(compareTab);
  await t.wait(3000);

  const initialCount = await addToCartSelector.count;
  console.log("Initial Add to Cart count:", initialCount);

  console.log("Clicking Remove button...");
  await t.click(removeButton.nth(0));
  await t.wait(2000);

  const successVisible = await successAlert.exists;
  console.log("Success alert visible:", successVisible);

  const afterCount = await addToCartSelector.count;
  console.log("Add to Cart count after removal:", afterCount);

  if (successVisible && afterCount === initialCount - 1) {
    testStatus = "PASS";
    console.log("PASS — Product successfully removed from comparison list.");
  } else {
    console.log(
      `FAIL — Expected success alert + count decrease. Found: alert=${successVisible}, count=${afterCount}/${initialCount}`,
    );
    await t
      .expect(successVisible)
      .ok("Expected .alert-success after removing product");
    await t
      .expect(afterCount)
      .eql(initialCount - 1, "Add to Cart count should decrease by 1");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Notifications shown: ${notificationsShown} / 5`);
  console.log(`Initial Add to Cart count: ${initialCount}`);
  console.log(`After removal count: ${afterCount}`);
  console.log(`Success alert visible: ${successVisible}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});

fixture`E-commerce Playground - Product Comparison Duplicate`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("TC007 - Product Comparison – Duplicate Product Handling", async (t) => {
  const TEST_ID = "TC007";
  const FUNCTION_NAME = "Product Comparison – Duplicate Product Handling";
  const TEST_NAME =
    "Try adding the same product twice to comparison and verify no product appears";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const notification = Selector("#notification-box-top");
  const compareTab = Selector('[aria-label="Compare"]');
  const addToCartSelector = Selector('[value="Add to Cart"]');

  let testStatus = "FAIL";
  let notificationsShown = 0;

  const firstProduct = Selector(".product-thumb-top").nth(0);
  const compareBtn = firstProduct.parent().find(".btn-compare");

  for (let i = 0; i < 2; i++) {
    console.log(`Clicking compare on the same product - attempt ${i + 1}`);
    await t.hover(firstProduct).wait(700).click(compareBtn);

    try {
      await t
        .expect(notification.exists)
        .ok(`Notification not shown on attempt ${i + 1}`);
      notificationsShown++;
      console.log(`Attempt ${i + 1}: notification shown.`);
    } catch {
      console.log(`Attempt ${i + 1}: notification NOT shown.`);
      await t
        .expect(notification.exists)
        .ok("Expected notification after clicking compare");
    }

    await t.wait(1000);
  }

  console.log("Navigating to comparison page...");
  await t.click(compareTab);
  await t.wait(3000);

  const addToCartCount = await addToCartSelector.count;
  console.log("Add to Cart elements found:", addToCartCount);

  if (addToCartCount === 0) {
    testStatus = "PASS";
    console.log(
      "PASS — No products added to comparison (duplicate prevented).",
    );
  } else {
    console.log(
      `FAIL — Expected 0 Add to Cart elements, found ${addToCartCount}.`,
    );
    await t
      .expect(addToCartCount)
      .eql(0, "Expected no products in comparison for duplicate product");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Notifications shown: ${notificationsShown}`);
  console.log(`Add to Cart elements found: ${addToCartCount}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});
