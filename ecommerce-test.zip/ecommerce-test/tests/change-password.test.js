import { Selector } from "testcafe";

fixture`E-commerce Playground - Change Password`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=account/login`;

test("TC008 - Change Password – Successful Password Update", async (t) => {
  const TEST_ID = "TC008";
  const FUNCTION_NAME = "Change Password – Successful Password Update";
  const TEST_NAME =
    "Login, navigate to Change Password, change successfully, verify success alert";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const loginEmail = "#input-email";
  const loginPassword = "#input-password";
  const submitBtn = Selector('input[type="submit"]');

  const newPassword = "Hoangtoan1999@";

  const alertSuccess = Selector(".alert-success");
  let testStatus = "FAIL";

  console.log("Logging in...");
  await t
    .typeText(loginEmail, "huydangquanghuy@gmail.com", {
      paste: true,
      replace: true,
    })
    .typeText(loginPassword, "Hoangtoan1999@", { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(3000);

  console.log("Navigating to Change Password page...");
  await t.navigateTo(
    "https://ecommerce-playground.lambdatest.io/index.php?route=account/password",
  );
  await t.wait(2000);

  console.log("Filling new password fields...");
  await t
    .typeText("#input-password", newPassword, { paste: true, replace: true })
    .typeText("#input-confirm", newPassword, { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(3000);
  const successVisible = await alertSuccess.exists;

  if (successVisible) {
    testStatus = "PASS";
    console.log(
      "PASS — Password changed successfully, success alert displayed.",
    );
  } else {
    console.log("FAIL — No success alert displayed after password change.");
    await t
      .expect(alertSuccess.exists)
      .ok("Expected .alert-success to appear after password change");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Success alert visible: ${successVisible}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});

fixture`E-commerce Playground - Change Password – Invalid Password Length`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=account/login`;

test("TC009 - Change Password – Invalid Password Length", async (t) => {
  const TEST_ID = "TC009";
  const FUNCTION_NAME = "Change Password – Invalid Password Length";
  const TEST_NAME =
    "Login, navigate to Change Password, enter short password, verify validation message";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const loginEmail = "#input-email";
  const loginPassword = "#input-password";
  const submitBtn = Selector('input[type="submit"]');
  const textDanger = Selector(".text-danger");

  const invalidPassword = "12";
  let testStatus = "FAIL";
  let errorMessage = "";

  console.log("Logging in...");
  await t
    .typeText(loginEmail, "huydangquanghuy@gmail.com", {
      paste: true,
      replace: true,
    })
    .typeText(loginPassword, "Hoangtoan1999@", { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(3000);

  console.log("Navigating to Change Password page...");
  await t.navigateTo(
    "https://ecommerce-playground.lambdatest.io/index.php?route=account/password",
  );
  await t.wait(2000);

  console.log("Filling invalid short password...");
  await t
    .typeText("#input-password", invalidPassword, {
      paste: true,
      replace: true,
    })
    .typeText("#input-confirm", invalidPassword, { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(2000);

  const textDangerExists = await textDanger.exists;
  if (textDangerExists) {
    errorMessage = await textDanger.innerText;
    console.log("Validation message found:", errorMessage);
  } else {
    console.log("No validation message found!");
  }

  const expectedMsg = "Password must be between 4 and 20 characters!";

  if (textDangerExists && errorMessage.includes(expectedMsg)) {
    testStatus = "PASS";
    console.log(
      "PASS — Correct validation message displayed for short password.",
    );
  } else {
    console.log(
      `FAIL — Expected validation message "${expectedMsg}" but got "${
        errorMessage || "none"
      }".`,
    );
    await t.expect(textDanger.innerText).contains(expectedMsg);
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Validation message: ${errorMessage}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});

fixture`E-commerce Playground - Change Password – Password Mismatch`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=account/login`;

test("TC0010 - Change Password – Password Mismatch", async (t) => {
  const TEST_ID = "TC009";
  const FUNCTION_NAME = "Change Password – Password Mismatch";
  const TEST_NAME =
    "Login, navigate to Change Password, enter short password, verify validation message";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const loginEmail = "#input-email";
  const loginPassword = "#input-password";
  const submitBtn = Selector('input[type="submit"]');
  const textDanger = Selector(".text-danger");

  let testStatus = "FAIL";
  let errorMessage = "";

  console.log("Logging in...");
  await t
    .typeText(loginEmail, "huydangquanghuy@gmail.com", {
      paste: true,
      replace: true,
    })
    .typeText(loginPassword, "Hoangtoan1999@", { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(3000);

  console.log("Navigating to Change Password page...");
  await t.navigateTo(
    "https://ecommerce-playground.lambdatest.io/index.php?route=account/password",
  );
  await t.wait(2000);

  console.log("Filling invalid short password...");
  await t
    .typeText("#input-password", "Toan1234", {
      paste: true,
      replace: true,
    })
    .typeText("#input-confirm", "Toan123", { paste: true, replace: true })
    .click(submitBtn);

  await t.wait(2000);

  const textDangerExists = await textDanger.exists;
  if (textDangerExists) {
    errorMessage = await textDanger.innerText;
    console.log("Validation message found:", errorMessage);
  } else {
    console.log("No validation message found!");
  }

  const expectedMsg = "Password confirmation does not match password!";

  if (textDangerExists && errorMessage.includes(expectedMsg)) {
    testStatus = "PASS";
    console.log(
      "PASS — Correct validation message displayed for short password.",
    );
  } else {
    console.log(
      `FAIL — Expected validation message "${expectedMsg}" but got "${
        errorMessage || "none"
      }".`,
    );
    await t.expect(textDanger.innerText).contains(expectedMsg);
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Validation message: ${errorMessage}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});
