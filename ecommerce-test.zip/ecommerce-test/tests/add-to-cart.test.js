import { Selector, t } from "testcafe";

fixture`TC001 - Add to cart successfully`
  .page`https://ecommerce-playground.lambdatest.io`;

test("TC001 - Add to cart successfully", async (t) => {
  const shopByCategory = Selector("div.shop-by-category a");
  await t.click(shopByCategory).wait(2000);

  const firstNavItem = Selector(".mz-pure-drawer.active .nav-item")
    .nth(0)
    .find("a");
  await t.click(firstNavItem).wait(3000);

  const firstProduct = Selector(".product-thumb-top").nth(0);
  const addToCartBtn = firstProduct.parent().find(".btn-cart");

  await t.hover(firstProduct).wait(1000).click(addToCartBtn);

  const notification = Selector("#notification-box-top");

  const testName = "TC001 - Add to cart successfully";
  const browserName = t.browser.name;

  try {
    await t
      .expect(notification.exists)
      .ok("Add to Cart failed — notification not displayed");
    console.log(`
==============================
TEST RESULT SUMMARY
==============================
File: add-to-cart.test.js
Browser: ${browserName}
Test name: ${testName}
Status: PASS
==============================
`);
  } catch (err) {
    console.log(`
==============================
TEST RESULT SUMMARY
==============================
File: add-to-cart.test.js
Browser: ${browserName}
Test name: ${testName}
Status: FAIL
Reason: ${err.errMsg || err.message}
==============================
`);
    throw err;
  }

  await t.wait(3000);
});

fixture`E-commerce Playground - Add to Cart Quantity Verification`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("TC002 - Add to Cart – Verify Quantity Update", async (t) => {
  console.log("Test Case ID: TC002");
  console.log("Function: Add to Cart – Verify Quantity Update");
  console.log("Browser:", t.browser.name);
  console.log(
    "Test name: Verify product quantity increases after adding twice",
  );

  const productThumb = Selector(".product-thumb-top").nth(0);
  const addToCartBtn = productThumb.parent().find(".btn-cart");
  const notification = Selector("#notification-box-top");

  await t.hover(productThumb).wait(1000).click(addToCartBtn);
  await t
    .expect(notification.exists)
    .ok("First Add to Cart failed — notification not displayed");
  console.log("First Add to Cart success!");

  await t.hover(productThumb).wait(1000).click(addToCartBtn);
  await t
    .expect(notification.exists)
    .ok("Second Add to Cart failed — notification not displayed");
  console.log("Second Add to Cart success!");

  await t.navigateTo(
    "https://ecommerce-playground.lambdatest.io/index.php?route=checkout/cart",
  );
  console.log("Navigated to cart page");

  const quantityInput = Selector(
    'form[action="https://ecommerce-playground.lambdatest.io/index.php?route=checkout/cart/edit"] input[type="text"]',
  ).nth(0);
  const quantityValue = await quantityInput.value;

  if (quantityValue === "2") {
    console.log("Status: PASS");
  } else {
    console.log(
      `FAIL — Quantity not updated correctly (found value = ${quantityValue})`,
    );
    await t
      .expect(quantityValue)
      .eql("2", "Quantity should be 2 after adding twice");
  }
});

fixture`E-commerce Playground - Add Multiple Products`
  .page`https://ecommerce-playground.lambdatest.io/index.php?route=product/category&path=25`;

test("TC003 - Add 2 Different Products – Verify Cart Total Count", async (t) => {
  const TEST_ID = "TC003";
  const FUNCTION_NAME = "Add Multiple Products – Verify Cart Total Count";
  const TEST_NAME = "Add 2 different products and verify .cart-item-total = 2";

  console.log("Running Test:", TEST_ID, "-", FUNCTION_NAME);
  console.log("Browser:", t.browser.name);

  const notification = Selector("#notification-box-top");
  const cartItemTotal = Selector(".cart-item-total");

  let testStatus = "FAIL";

  for (let i = 0; i < 2; i++) {
    const productThumb = Selector(".product-thumb-top").nth(i);
    const addToCartBtn = productThumb.parent().find(".btn-cart");

    console.log(`Adding product ${i + 1}...`);
    await t.hover(productThumb).wait(800).click(addToCartBtn);
    await t
      .expect(notification.exists)
      .ok(`Add to Cart failed for product ${i + 1}`);
    console.log(`Product ${i + 1} added successfully.`);
    await t.wait(1500);
  }

  const cartTotalText = (await cartItemTotal.innerText).trim();
  console.log("Cart item total displayed:", cartTotalText);

  if (cartTotalText === "2") {
    console.log("PASS — Cart total count is correct (2 items).");
    testStatus = "PASS";
  } else {
    console.log(`FAIL — Expected 3 items, but found ${cartTotalText}.`);
    await t
      .expect(cartTotalText)
      .eql("3", "Cart total should be 2 after adding 2 items.");
  }

  console.log("\n==================== TEST SUMMARY ====================");
  console.log(`Test Case ID: ${TEST_ID}`);
  console.log(`Function Name: ${FUNCTION_NAME}`);
  console.log(`Browser: ${t.browser.name}`);
  console.log(`Test Name: ${TEST_NAME}`);
  console.log(`Status: ${testStatus}`);
  console.log("======================================================\n");
});
